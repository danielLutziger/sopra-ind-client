declare const _exports: typeof plugin.default;
export = _exports;
import plugin = require("./index");
