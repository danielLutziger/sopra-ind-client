export function trueCasePath(
  filePath: string,
  basePath?: string
): Promise<string>

export function trueCasePathSync(filePath: string, basePath?: string): string
