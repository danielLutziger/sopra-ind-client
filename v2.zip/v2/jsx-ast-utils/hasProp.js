module.exports = require('./lib').hasProp; // eslint-disable-line import/no-unresolved
