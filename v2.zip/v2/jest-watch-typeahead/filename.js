export { default } from './build/file_name_plugin/plugin.js';
