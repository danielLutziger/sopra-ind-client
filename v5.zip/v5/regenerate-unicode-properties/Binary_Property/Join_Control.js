const set = require('regenerate')();
set.addRange(0x200C, 0x200D);
module.exports = set;
