const set = require('regenerate')();
set.addRange(0x10F30, 0x10F59);
module.exports = set;
