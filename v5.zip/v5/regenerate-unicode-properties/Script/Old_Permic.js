const set = require('regenerate')();
set.addRange(0x10350, 0x1037A);
module.exports = set;
