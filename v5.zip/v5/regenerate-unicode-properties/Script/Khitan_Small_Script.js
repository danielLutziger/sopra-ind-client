const set = require('regenerate')(0x16FE4);
set.addRange(0x18B00, 0x18CD5);
module.exports = set;
