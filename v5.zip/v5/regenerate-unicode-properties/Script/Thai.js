const set = require('regenerate')();
set.addRange(0xE01, 0xE3A).addRange(0xE40, 0xE5B);
module.exports = set;
