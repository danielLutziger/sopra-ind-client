import runner from "@babel/helper-plugin-test-runner";

runner(import.meta.url);
