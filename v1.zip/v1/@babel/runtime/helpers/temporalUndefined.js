function _temporalUndefined() {}
module.exports = _temporalUndefined, module.exports.__esModule = true, module.exports["default"] = module.exports;