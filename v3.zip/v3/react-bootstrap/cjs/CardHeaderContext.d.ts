import * as React from 'react';
interface CardHeaderContextValue {
    cardHeaderBsPrefix: string;
}
declare const context: React.Context<CardHeaderContextValue | null>;
export default context;
