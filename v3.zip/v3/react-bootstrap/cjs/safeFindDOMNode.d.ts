/// <reference types="react" />
export default function safeFindDOMNode(componentOrElement: React.Component | Element | null | undefined): Element | Text | null;
