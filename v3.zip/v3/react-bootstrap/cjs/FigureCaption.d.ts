declare const FigureCaption: import("./helpers").BsPrefixRefForwardingComponent<"figcaption", unknown>;
export default FigureCaption;
