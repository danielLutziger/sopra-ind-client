## 3.0
* Use PostCSS 7.x
* Bump various dependencies

## 2.0
* Use PostCSS 6.x
* Use Node 4.x syntax

## 1.0
* Initial release
